package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.security.auth.login.AccountException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.utilities.PayrollUtility;

@Component("payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {

	@Autowired	

	private SessionFactory sessionFactory;

	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAssociate(int associateID) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Associate getAssociate(int associateID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Associate> getAssociates() {
		// TODO Auto-generated method stub
		return null;
	}

}
