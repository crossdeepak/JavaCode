package com.cg.services;

public class MainClass {

	public static void main(String[] args) {
		MathServices mathServices=new MathServicesImpl();
		System.out.println(mathServices.add(20, 60));
		System.out.println(mathServices.subs(50, 30));
		System.out.println(mathServices.mul(10, 6));
		

	}

}
