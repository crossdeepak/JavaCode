package com.cg.services;

public interface MathServices {
	public int add(int n1,int n2);
	int subs(int n1, int n2);
	int mul(int n1,int n2);
}
