package com.cg.services;

public class MathServicesImpl implements MathServices{

	@Override
	public int add(int n1, int n2) {
		return n1+n2;
	}

	@Override
	public int subs(int n1, int n2) {
		// TODO Auto-generated method stub
		return n1-n2;
	}

	@Override
	public int mul(int n1, int n2) {
		// TODO Auto-generated method stub
		return n1*n2;
	}

}
