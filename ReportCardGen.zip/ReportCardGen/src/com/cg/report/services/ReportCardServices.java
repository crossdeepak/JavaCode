package com.cg.report.services;

public interface ReportCardServices {
	
}
