package com.cg.report.services;

public class ReportCardServicesImpl {

}
