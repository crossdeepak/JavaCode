package com.cg.report.utility;

public class ReportCardUtility {
	public static int STUDENT_ID_COUNTER=1;
	public static int SUBJECT_ID_COUNTER=101;
}
